""""Reforzamiento 02"""

"""Ejercicio 10"""

# Definir variables
nombre = "Rosa Gamarra"
carrera = "Física"
edad = 19
año_nacimiento = 2005

# Diccionario
estudiante = {
    "nombre": nombre,
    "carrera": carrera,
    "edad": edad,
    "año de nacimiento": año_nacimiento
}

print(estudiante)