""""Reforzamiento 02"""

"""Ejercicio 11"""

#Variable edad
edad = 19

result = (edad ** 5) / 10

print("Tipo de resultado: {}".format(type(result)))

#Módulo %3
mod_edad = edad % 3

print("Modulo de resultado: {}".format(mod_edad))