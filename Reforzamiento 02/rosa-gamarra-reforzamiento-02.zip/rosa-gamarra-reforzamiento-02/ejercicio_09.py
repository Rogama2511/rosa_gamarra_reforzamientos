""""Reforzamiento 02"""

"""Ejercicio 09"""

#Definir valor
valor = 3

#Operación
result = (valor ** 6) - (valor * 2)

print("El resultado es: {} ".format(result))
