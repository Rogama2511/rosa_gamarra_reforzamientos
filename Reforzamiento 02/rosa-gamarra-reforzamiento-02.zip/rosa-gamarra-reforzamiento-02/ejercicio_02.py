""""Reforzamiento 02"""

"""Ejercicio 02"""

#Definir variable
var_1 = 6

#Operación
result = (var_1 * 10) - 10
result_float = float(result)

print("Resultado de la operación: {}".format(result_float))
print("Tipo de variable: {}".format(type(result_float)))

