""""Reforzamiento 02"""

"""Ejercicio 01"""

#Definir variables
mi_nombre = "Rosa Gamarra"
mi_saludo= f"¡Hi {mi_nombre}!"

print(mi_saludo)
