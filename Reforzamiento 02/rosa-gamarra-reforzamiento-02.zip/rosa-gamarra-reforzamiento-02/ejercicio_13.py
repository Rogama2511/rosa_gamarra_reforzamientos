""""Reforzamiento 02"""

"""Ejercicio 13"""

#Lista inicial
temas_fis = ["Ecuaciones de Maxwell", "Campos eléctricos y magnéticos",
             "Leyes de la termodinámica", "Interferencia y difracción",
             "Ecuación de Schrödinger", "Distribución de Maxwell-Boltzmann"]

print("Lista inicial de temas: {}".format(temas_fis))

#Agregar 4 temas nuevos
temas_fis.extend(["Relatividad Especial", "Difracción de Fresnel",
                     "Ondas electromagnéticas", "Radiación de cuerpo negro"])

print("Lista actualizada de temas: {}".format(temas_fis))

