""""Reforzamiento 02"""

"""Ejercicio 06"""

#Datos
var_1 = 16.47
var_2 = 14.28
var_3 = 18.58
var_4 = 19.24
var_5 = 13.56

#Calculo de la media
media = (var_1 + var_2 + var_3 + var_4 + var_5) / 5

print("Valor de la media es {}".format(media))
print("Tipo de dato: {}".format(type(media)))
