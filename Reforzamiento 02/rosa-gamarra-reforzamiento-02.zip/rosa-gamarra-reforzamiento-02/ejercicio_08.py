""""Reforzamiento 02"""

"""Ejercicio 08"""

#Definir listas
list_1 = []
list_2 = [3, 5, 6, 5]

#Verificar si la lista 1 esta vacía
if len(list_1) == 0:
    print("La lista esta vacía")
else :
    print("La lista tiene {} elementos".format(len(list_1)))

# Verificar si la lista 2 esta vacía
if len(list_2) == 0:
    print("La lista esta vacía")
else:
    print("La lista tiene {} elementos".format(len(list_2)))

