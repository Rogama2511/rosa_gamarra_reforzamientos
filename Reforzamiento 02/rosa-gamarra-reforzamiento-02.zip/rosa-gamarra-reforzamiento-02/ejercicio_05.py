""""Reforzamiento 02"""

"""Ejercicio 05"""

#Definir Variable
sueldo = 1256

#Veriicar si es par o impar
if sueldo % 2 == 0 :
    print("El sueldo {} es par" .format(sueldo))
else :
    print("El sueldo {} es impar" .format(sueldo))

    