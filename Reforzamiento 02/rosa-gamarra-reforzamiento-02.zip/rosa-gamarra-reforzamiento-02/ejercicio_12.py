""""Reforzamiento 02"""

"""Ejercicio 12"""

#Definir lista y datos
list_1 =["Rosa", "Gamarra", 32, 10, 5.4, 8.3, "2025-1", True, False]
list_2 = [2, 4, 6, 8, 10, 12]

sum_list = list_1 + list_2

print("Lista mixta:", list_1)
print("Lista de números pares:", list_2)
print("Lista combinada:", sum_list)

"""Comentario: 
    Al sumar listas con `+`, los elementos de la segunda lista se agregan al final de la primera lista.
    No se realiza una suma matemática"""