""""Reforzamiento 02"""

"""Ejercicio 07"""

#Definir números
num_1 = 65
num_2 = -33
num_3 = 43

#Calculo de los módulos
mod_1 = num_1 % 3
mod_2 = num_2 % 5
mod_3 = num_3 % 7

suma_mod = mod_1 + mod_2 + mod_3

print("La suma de los módulos es: {}".format(suma_mod))

