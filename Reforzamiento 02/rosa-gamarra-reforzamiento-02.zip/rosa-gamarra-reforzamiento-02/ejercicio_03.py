""""Reforzamiento 02"""

"""Ejercicio 03"""

#Definir Variables
var_str = "120"
var_int = 34

#Operación
suma = int(var_str) + var_int

print("Resultado :{}".format(suma))
