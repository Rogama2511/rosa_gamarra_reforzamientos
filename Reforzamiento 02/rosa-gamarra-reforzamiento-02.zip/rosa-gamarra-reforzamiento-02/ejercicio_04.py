""""Reforzamiento 02"""

"""Ejercicio 04"""

#Definir radio
radio = 4
pi = 3.141592

# Volumen de la esfera
vol_esfera = (4/3) * pi * (radio ** 3)

print("Volumen de la esfera: {:.3f}" .format(vol_esfera))
