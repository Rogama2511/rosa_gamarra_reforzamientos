"""Reforzamiento 03"""

"""Ejercicio 06"""

""" 6. Elimina ahora todos los elementos de la lista creada previamente y mostrar en 
consola la lista actualizada agregando tu nombre, apellido paterno, apellido materno y edad"""

lista = [3.5, 20.54, True, 3.9, 2.1, False, 9.3, True]

#Vaciar lista
lista.clear()

#Agregar datos
lista.append("Rosa")
lista.append("Gamarra")
lista.append("Aguirre")
lista.append(19)

print("Lista actualizada es:{}".format(lista))


