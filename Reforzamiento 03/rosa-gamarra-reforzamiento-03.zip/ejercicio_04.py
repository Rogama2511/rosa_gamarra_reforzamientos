"""Reforzamiento 03"""

"""Ejercicio 04"""

"""4. Crea dos listas (una de datos string y la otra de datos numéricos) 
para luego usar los métodos de orden (los elementos tienen que estar desordenados), 
mostrar las listas antes y después de aplicarle los métodos de orden """

#Listas
list_str = ["Lima", "Bogota", "Tokyo", "París"]
list_num = [5.4, 2.53, 10.3, 8.4, 6.3]

print("Lista de datos string: {}".format(list_str))
print("Lista de datos númericos: {}".format(list_num))

#Ordenar
list_str.sort()
list_num.sort()

print(" ")
print("Listas ordenadas")
#Listas ordenadas
print("Lista de datos string: {}".format(list_str))
print("Lista de datos númericos: {}".format(list_num))